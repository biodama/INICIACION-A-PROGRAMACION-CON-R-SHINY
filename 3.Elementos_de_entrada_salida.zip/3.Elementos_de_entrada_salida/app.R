library(shiny)

### ELEMENTOS DE ENTRADA
ui <- fluidPage(
  br(),
  textInput("id_t", "Etiqueta", placeholder = "Rellenar con texto"),
  br(),br(),
  numericInput("id_n","Etiqueta", value = 2, min=0, max=10, step=2),
  br(),br(),
  checkboxInput("id_c", "un check"),
  br(),br(),
  checkboxGroupInput("id_g", "Grupo de checks", choices = c("opción 1", "opción 2", "opción 3")),
  br(),br(),
  selectInput("id_s", "Selecciona", choices = c(1:5)),
  br(),br(),
  radioButtons("id_r", "Grupo de radiobuttons", choices = c("opción 1", "opción 2", "opción 3")),
  br(),br(),
  actionButton("id", label = "Botón"),
  br(),br(),
  actionLink("id_l", label = "Enlace"),
  br(),br(),
  submitButton("boton submit"),
  br(),br(),
  sliderInput("rango1", "Rango 1:", value=4, min = 0, max = 10, step=0.5), # Slider con paso 0.5
  br(),br(),
  sliderInput("rango2", "Rango 2:", min = 0, max = 100, value = c(20, 80)), # Slider con limite inferior
  br(),br(),
  fileInput("id_f", "Fichero"),
  br(),br(),
  dateInput("id_d",label = "Calendario"),
  br(),br(),
  helpText("Texto de ayuda"),
  br(),br(),

  tags$a("CNE", href="https://cne.isciii.es/"),
  br(),br(),
  h2("Texto Head 2"),
  br(),br(),

  # Otros paquetes, con controles adicionales:
  require("shinyWidgets"),

  switchInput(inputId = "id", value = TRUE),

  prettyToggle(
    inputId = "id",
    label_on = "Checked!",
    label_off = "Unchecked..."
  ),

  dropdownButton(
    tags$h3("List of Input"),
    selectInput(inputId = 'xcol', label = 'X Variable', choices = names(iris)),
    selectInput(inputId = 'ycol', label = 'Y Variable', choices = names(iris), selected = names(iris)[[2]]),
    sliderInput(inputId = 'clusters', label = 'Cluster count', value = 3, min = 1, max = 9),
    circle = TRUE,
    status = "danger",
    icon = icon("gear"), width = "300px",
    tooltip = tooltipOptions(title = "Click to see inputs !")
  ),

  br(),
  br(),
  br(),

  textOutput("variable"),

  br(),
  br(),

  verbatimTextOutput("air"),
  br(),
  br(),
  textOutput("airT"),  # Diferencia de un summary con verbatimTextOutput

  br(),
  br(),

  imageOutput("id_imagen", width = "100%", height = "400px", inline = FALSE),
  br(),
  br(),

  plotOutput(outputId="id_plot"),
  br(),
  br(),

  tableOutput('id_tabla'),
  br(),
  br(),

  DT::DTOutput('id_tabla_DT', width = "30%"),
  br(),
  br(),

  uiOutput("id_input_dinamico"),
  br(),
  br(),

  htmlOutput("id_html_dinamico"),
  br(),
  br()

)

server <- function(input, output, session) {

  output$variable <- renderText({
    "Ejemplo de textOutput"
  })

  output$air <- renderPrint({
    summary(airquality)
  })
  output$airT<- renderText({
    summary(airquality)
  })

  output$id_imagen <- renderImage({list(src = "www/CNE.svg", width = 200, height = 200)}, deleteFile = FALSE)

  output$id_plot <- renderPlot(hist(airquality$Temp))

  output$id_tabla <- renderTable(airquality[c(1:10),]) # 10 primeras filas de la tabla

  output$id_tabla_DT <- DT::renderDT(airquality[,c(1:3)], options = list(lengthChange = FALSE) ) # 3 primeras columnas de la tabla

  output$id_input_dinamico <- renderUI({numericInput("valor", "Ingresa un número", value = 0) })

  output$id_html_dinamico <- renderUI({HTML("<span>Contenido</span><b>&nbsp;HTML</b> <i>dinámico</i>")})


  # Actualización de 'inputs' desde el 'servidor'
  updateSelectInput(session = session, inputId = "id_s", label = "Selecciona", choices = c("a","b","c","d"), selected = "b")

  #updateActionButton(session = session, inputId = "id", label = "Botón actualizado")

}

shinyApp(ui = ui, server = server)

