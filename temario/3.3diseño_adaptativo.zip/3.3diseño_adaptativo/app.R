###
### 3.3 Diseño adaptativo
###

library(shiny)

### ELEMENTOS DE ENTRADA
ui <- fluidPage(

  fluidRow(
    column(1,),
    column(5, align="center",
           textInput("id_t", "Etiqueta", placeholder = "Rellenar con texto"),
           ),
    column(5, align="center",
           numericInput("id_n","Etiqueta", value = 2, min=0, max=10, step=1),
           ),
    column(1,"")
  ),

  fluidRow(
    column(1,""),
    column(5, align="center",
           checkboxInput("id_c", "un check"),
           ),
    column(5, align="center",
           selectInput("id_s", "Selecciona", choices = c(1:5)),
           ),
    column(1,"")
  )

)

server <- function(input, output, session) {

}

shinyApp(ui = ui, server = server)

