library(shiny)

### Parte cliente
ui <- fluidPage(

  numericInput("id1", label = "Introduzca nº", value = 2, min=0, max=5),

  # # 1.
   textOutput("id2"),
  #
  # # 3.
  br(),
  textInput("id_texto", label = NULL, placeholder = "Introduzca texto"),

  # Salida reactiva
  br(),
  textOutput("salidaTexto"),

  br(),
  fileInput("id_fich", "fichero de prueba:")
)

