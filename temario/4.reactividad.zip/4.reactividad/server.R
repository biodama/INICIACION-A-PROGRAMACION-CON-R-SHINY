### Parte servidor - Ejemplos de funcionamiento de las fcs. y elementos reactivos
server <- function(input, output) {

  # 1. Ejemplo con 'reactive'
  vble_reactiva <- reactive({
    as.numeric(input$id1 + 1)
  })

  # print(c("Es reactiva:",is.reactive(vble_reactiva) ) )
  output$id2 <- renderText(vble_reactiva() )


  # 2. Ejemplo con 'observe'
  # observe({
  #     print(c("vble_reactiva:", vble_reactiva()))
  # })


  # 3. Ejemplo con 'observeEvent'
  # observeEvent( eventExpr=input$id_texto ,{     # El evento se dispara cuando se modifica 'id_texto'
  #   print(" ---- PRINT de observeEvent")
  #   print(c("id1:", input$id1))            # El contenido del observeEvent que se ejecuta, puede incluir la variable que arranca el evento o no (como este caso).
  #   print(c("vble_reactiva:", vble_reactiva()))
  # })


  # 4. Ejemplo con 'reactiveValues' 'reactiveVal'
  Datos <- reactiveVal("primer valor")

  observe(print(c("Datos:", Datos))) # No imprime el valor que tiene 'Datos' en este momento, sino el último valor que toma.

  Datos <-"dato1 modificado"  # En este caso, la reactividad no se inicia en el 'ui', sino en el 'server'
  Datos <-"dato1 ..."


  ### Salidas reactivas (render...)
  output$salidaTexto <- renderText(input$id1)


  # Ejemplo supresión de reactividad (isolate)
  # observe({
  #   print(c("isolate - id1:", isolate(input$id1)))
  #   print(c("id_texto:", input$id_texto))
  # })






  ## ?

  #write.csv(airquality,file="airquality.csv")  # Escritura de fichero de ej. para probar
  mis_datos <- reactive({
    req(input$id_fich)
    read.csv(
      input$id_fich$datapath,
      stringsAsFactors = FALSE
    )
  })

  observe({
    print(c("mis_datos:", mis_datos() ))
  })

}
