###
### 7.2. Paneles
###

library(shiny)
library(shinydashboard)

### Parte cliente
ui <- fluidPage(

  tabsetPanel(id='id_tabset',
    tabPanel("Entrada de datos",
             br(),
             selectInput("id_meses", label = "Mes", choices = unique(airquality$Month)),
             br(),
             sliderInput("id_temp", label="Temperatura", min=min(airquality$Temp), max = max(airquality$Temp), value = c(min(airquality$Temp),max(airquality$Temp)) )
             ),
    tabPanel("Resultados",
             br(),br(),
             DT::DTOutput('id_tabla_DT', width = "70%")
             )
  )

)

