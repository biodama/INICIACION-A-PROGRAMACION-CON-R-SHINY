### Parte servidor
server <- function(input, output) {

  output$id_tabla_DT <- DT::renderDT(airquality)

  observe({
    # filtrado de datos según 'inputs' del dashboard
    output$id_tabla_DT <- DT::renderDT(
                                   airquality[airquality$Month%in%input$id_meses & airquality$Temp%in%c(input$id_temp[1]:input$id_temp[2]), ]
                              )
  })


  observeEvent(c(input$id_meses, input$id_temp),{
   output$id_texto <- renderText(paste0("Rango de temperatura: ", input$id_temp[1],"-",input$id_temp[2], " para el mes: ", input$id_meses))
  })

}
