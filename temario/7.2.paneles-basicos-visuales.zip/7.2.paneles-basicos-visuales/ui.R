###
### 7.2. Paneles
###

library(shiny)
library(shinydashboard)

### Parte cliente
ui <- fluidPage(

  titlePanel("Panel básico - Airquality"),

  sidebarLayout(
    sidebarPanel(
      br(),
      selectInput("id_meses", label = "Mes", choices = unique(airquality$Month)),
      br(),
      sliderInput("id_temp", label="Temperatura", min=min(airquality$Temp), max = max(airquality$Temp), value = c(min(airquality$Temp),max(airquality$Temp)) )
    ),
    mainPanel(
    fluidRow(
      column(2,""),
      column(8,align="center",
             br(),br(),
             DT::DTOutput('id_tabla_DT', width = "70%")
             ),
      column(2,"")
    ),

    br(),

    wellPanel(
      h4("Panel"),
      textOutput("id_texto")
    )
  )
  )
)

