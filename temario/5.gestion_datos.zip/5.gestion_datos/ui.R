library(shiny)

# Generación de los datos de prueba
# openxlsx::write.xlsx(x=airquality, file="airquality.xlsx")

### Parte cliente
ui <- fluidPage(

  # 1. Carga de datos
  br(),
  fileInput("id_carga", label="fichero excel", accept = ".xlsx", placeholder = ".xlsx"),
  br(),

  DT::dataTableOutput("id_tabla"),



  # 2. Descarga de datos
  br(),
  downloadButton('id_descarga','Descargar datos'),


  # Ventana modal
  br(),br(),
  actionButton("id_borrar", label = "Borrar datos")

)

