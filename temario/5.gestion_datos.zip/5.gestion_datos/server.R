### Parte servidor
###
### 5. Gestión de datos y seguridad.
###

server <- function(input, output) {

  # # 5.1. Lectura de datos desde ficheros externos.
  # datos <- reactive({
  #
  #   shiny::req(input$id_carga)
  #   aux <- openxlsx::read.xlsx(xlsxFile=input$id_carga$datapath)
  #   str(aux)
  #
  #   # Validación del formato del fichero
  #   dup <- duplicated(names(aux))
  #   shiny::validate(need(sum(dup)==0,paste("Hay variables duplicadas!:",names(aux)[dup])))
  #
  #   aux
  #
  # })

  #output$id_tabla <- DT::renderDT( datos() )  # datos la utilizamos como función reactiva.

  # # Mediante ObserveEvent y shinyalert (Más vistoso)
  #
  library("shinyalert")

  useShinyalert() # carga las funciones necesarias para el funcionamiento de las librerias

  observeEvent(input$id_carga,{
    aux <- openxlsx::read.xlsx(xlsxFile=input$id_carga$datapath)

    # Validación del formato del fichero
    dup <- duplicated(names(aux))
    print(sum(dup))
    if (sum(dup)>0) {
      shinyalert::shinyalert(title="Mensaje de Error", text="Hay variables duplicadas!")
      return(NULL) # Finalizamos la ejecución del observe para no actualizar la tabla con datos erroneos.
    }

    output$id_tabla <- DT::renderDT( aux )

   })


  # # 5.2. Descarga de ficheros
  output$id_descarga <- downloadHandler(
    filename = function() {
      paste("curso_R_Shiny_",as.character(Sys.Date()) ,".xlsx", sep="")
    },
    content = function(file) {
      sub_base <- airquality[ ,c(1:3)]
      openxlsx::write.xlsx(sub_base, file)
    }
  )
  #
  #
  # # Ventanas modales
  #
  observeEvent(input$id_borrar,{

  showModal(modalDialog(
    title = "¡Aviso!",
    "Se va a proceder a borrar los datos. ¿Estas seguro/a?",
    easyClose = FALSE,
    footer = column(align="center", 12, actionButton("OK.Continuar", "Continuar"), modalButton("Cancelar")),
    size = c("l")
  ))

  })
  #
  observeEvent(input$OK.Continuar, {

    # Aqui pondriamos el codigo de borrado de los datos

    shinyalert::shinyalert("Datos borrados!", type = "success")

    removeModal()  # Cerrar la ventana Modal

  })



}







#output$OK.Continuar <- renderText("0")  # Shiny, autoincrementa el valor del botón cuando se pulse
