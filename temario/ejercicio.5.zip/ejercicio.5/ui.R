library(shiny)

### Parte cliente
ui <- fluidPage(

   fileInput("id_carga", label = "fichero de datos:", accept = ".xlsx", placeholder = "Adjunta tu excel"),
   br(),
   
   selectInput("id_x", label = "Vble. eje X", choices = NULL),
   br(),
   selectInput("id_y", label = "Vble. eje Y", choices = NULL),
   br(),
   plotOutput("id_plot", width = "100%", height = "25vw"),
   br(),
   downloadButton('id_descarga','Descargar datos')
   
)

