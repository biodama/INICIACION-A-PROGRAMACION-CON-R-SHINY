library(shiny)
library(openxlsx)
library(ggplot2)

# ejemplo de constante
nombre_fich <- paste0("curso_R_Shiny_", as.character(Sys.Date()),".xlsx")

# ejemplo de funcion
fc_grafico <- function(datos=airquality, x="Wind", y="Month") {
  
  ggplot(data=datos)+
    geom_histogram(aes(x=datos[[x]]))+
    facet_grid(~datos[[y]])
}



