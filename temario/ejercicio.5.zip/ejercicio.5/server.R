### Parte servidor
server <- function(input, output, session) {

  # upload de fichero de datos
  datos <- reactive({
    
    shiny::req(input$id_carga)
    aux <- openxlsx::read.xlsx(xlsxFile=input$id_carga$datapath)  # aux es una variable 'local' al codigo de 'reactive'
    str(aux)
    
    # Validación del formato del fichero
    dup <- duplicated(names(aux))
    shiny::validate(need(sum(dup)==0,paste("Hay variables duplicadas!:",names(aux)[dup])))
    
    aux
    
  })
  
  output$id_plot <- renderPlot( fc_grafico() )  # datos la utilizamos como función reactiva.
  
  
  # Actualización de los combos, según el fichero de datos importado
  observeEvent(input$id_carga, {
    aux <- datos()
    aux2 <- c()
    for (i in 1:dim(aux)[2]) {
      if (length(unique(aux[,i])) < 10) {
        aux2 <- c(aux2, names(aux)[i])
      }
    }
    
    updateSelectInput(session=session, 'id_x', choices = c("", names(aux)) )
    updateSelectInput(session=session, 'id_y', choices = c("", aux2 ) )
    
  })
  
  
  # Control del eje X
  observeEvent(input$id_x, {
    
    if ((!is.null(input$id_x)) & (input$id_x != "") & (!is.null(input$id_y)) & (input$id_y != "") ) {
      output$id_plot <- renderPlot( fc_grafico(datos(), x=input$id_x, y=input$id_y) )
    }
    
  })
  
  # Control del eje Y
  observeEvent(input$id_y, {
    
    if ((!is.null(input$id_y)) & (input$id_y != "") & (!is.null(input$id_x)) & (input$id_x != "") ) {
      output$id_plot <- renderPlot( fc_grafico(datos(), x=input$id_x, y=input$id_y) )
    }
    
  })
  
  # Descarga de ficheros
  output$id_descarga <- downloadHandler(
    filename = function() {
      nombre_fich   # Utilizamos una variable 'global'
    },
    content = function(file) {
      openxlsx::write.xlsx(datos(), file)
    }
  )
  
  
}
