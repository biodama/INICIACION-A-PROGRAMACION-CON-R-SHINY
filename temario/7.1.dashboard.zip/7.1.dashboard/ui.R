library(shiny)
library(shinydashboard)

### Parte cliente
ui <- dashboardPage(
  dashboardHeader(title = "Dashboard - Airquality",
                  dropdownMenuOutput("id_menu")
                  ),

  dashboardSidebar(
    selectInput("id_meses", label = "Mes", choices = unique(airquality$Month)),
    br(),
    sliderInput("id_temp", label="Temperatura", min=min(airquality$Temp), max = max(airquality$Temp), value = c(min(airquality$Temp),max(airquality$Temp)) )
  ),

  dashboardBody(
    fluidRow(
      column(2,""),
      column(8,align="center",
             br(),br(),
             DT::DTOutput('id_tabla_DT', width = "70%")
             ),
      column(2,"")
    )
  )
)

