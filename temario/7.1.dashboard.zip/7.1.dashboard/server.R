### Parte servidor
server <- function(input, output) {

  output$id_tabla_DT <- DT::renderDT(airquality)

  observe({
    # filtrado de datos según 'inputs' del dashboard
    output$id_tabla_DT <- DT::renderDT(
                                   airquality[airquality$Month%in%input$id_meses & airquality$Temp%in%c(input$id_temp[1]:input$id_temp[2]), ]
                              )
  })

  # actualizacion del menu de notificaciones, en funcion de la modificación de los meses y temperatura
  observeEvent(c(input$id_meses, input$id_temp),{

    # actualización del menu desplegable
    output$id_menu <- renderMenu({
      msgs <- list(
        messageItem(
          from = "Admin",
          message = paste("Mes seleccionado:", input$id_meses),
          time = "Ahora"
        ),
        messageItem(
          from = "Admin",
          message = paste0("Rango de temperatura: ", input$id_temp[1],"-",input$id_temp[2]),
          time = "Ahora"
        )
      )

      dropdownMenu(type = "messages", .list = msgs)
    })

  })




}
