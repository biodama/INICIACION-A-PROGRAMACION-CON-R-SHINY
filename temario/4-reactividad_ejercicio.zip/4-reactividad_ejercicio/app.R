library(shiny)
library("DT")

### ELEMENTOS DE ENTRADA
ui <- fluidPage(
  br(),
  fluidRow(
       column(12, align="center",
              h2("Ejercicio E/S"))
           ),
  br(),br(),
  fluidRow(
       column(1,""),
       column(5,
              br(),br(),
              selectInput("id_select", "Seleccione variable de control:", choices = names(cars), selected = names(cars)[1]),
              br(),br(),
              sliderInput("id_rango", "Rango de velocidad:", min = min(cars$speed), max = max(cars$speed), value = c(min(cars$speed)+1, max(cars$speed)-1)), # Slider con limite inferior
              br(),br()
       ),
       column(5,
              DT::DTOutput('id_tabla')
       ),
       column(1,"")
  )

)

server <- function(input, output, session) {

  output$id_tabla <- renderTable(cars)

  datos_filtrados <- reactive({
    subset(cars, speed >= input$id_rango[1] & speed <= input$id_rango[2])
  })

  observeEvent(input$id_select,{
    literal <- ifelse(input$id_select=="speed", "Rango de velocidad:", "Rango de distancia:")
    updateSliderInput(session = session, inputId = "id_rango", label= literal,
                      min = min(cars[,input$id_select]), max = max(cars[,input$id_select]),
                      value = c(min(cars[,input$id_select])+1, max(cars[,input$id_select])-1)
                      )

  })

  # Renderizado de la tabla
  output$id_tabla <- renderDT({
    datatable(
      datos_filtrados(),
      options = list(pageLength = 10, autoWidth = TRUE),
      rownames = TRUE
    )
  })

}

shinyApp(ui = ui, server = server)

