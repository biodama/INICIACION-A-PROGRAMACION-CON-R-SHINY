library(shiny)

### ELEMENTOS DE ENTRADA
ui <- fluidPage(
  br(),
  fluidRow(
       column(12, align="center",
              h2("Ejercicio E/S"))
           ),
  br(),br(),
  fluidRow(
       column(1,""),
       column(5,
              br(),br(),
              sliderInput("id_rango", "Rango de velocidad:", min = min(cars$speed), max = max(cars$speed), value = c(min(cars$speed)+1, max(cars$speed)-1)), # Slider con limite inferior
              br(),br()
       ),
       column(5,
              tableOutput('id_tabla')
       ),
       column(1,"")
  )

)

server <- function(input, output, session) {

  output$id_tabla <- renderTable(cars)

}

shinyApp(ui = ui, server = server)

