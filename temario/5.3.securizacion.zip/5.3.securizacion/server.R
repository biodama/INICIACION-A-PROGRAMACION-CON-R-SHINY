### Parte servidor
###
### 5.3 Securización.
###

server <- function(input, output) {

  # Definimos usuarios y contraseñas
  credentials <- data.frame(
    user = c("admin", "user"),
    password = c("123", "abc"),
    stringsAsFactors = FALSE
  )

  secure_server(check_credentials(credentials))


  ###############################################
  # Aqui empieza el codigo de nuestra aplicacion.

  # upload de fichero de datos
  datos <- reactive({

    shiny::req(input$id_carga)
    aux <- openxlsx::read.xlsx(xlsxFile=input$id_carga$datapath)
    str(aux)

    # Validación del formato del fichero
    dup <- duplicated(names(aux))
    shiny::validate(need(sum(dup)==0,paste("Hay variables duplicadas!:",names(aux)[dup])))

    aux

  })

  output$id_tabla <- DT::renderDT( datos() )  # datos la utilizamos como función reactiva.


  # Descarga de ficheros
  output$id_descarga <- downloadHandler(
    filename = function() {
      paste("curso_R_Shiny", ".xlsx", sep="")
    },
    content = function(file) {
      sub_base <- airquality[ ,c(1:3)]
      openxlsx::write.xlsx(sub_base, file)
    }
  )

}
