### Parte cliente
###
### 5.3 Securización.
###

library(shiny)
library(shinymanager)

ui <- shinymanager::secure_app(
  fluidPage(

    br(),
    fileInput("id_carga", label="fichero excel", accept = ".xlsx", placeholder = ".xlsx"),
    br(),

    DT::dataTableOutput("id_tabla"),

    br(),
    downloadButton('id_descarga','Descargar datos'),


  )
  #, language="es"
)

