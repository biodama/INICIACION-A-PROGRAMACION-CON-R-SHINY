library(shiny)
library(DT)
library(reactable)



### Parte cliente
ui <- fluidPage(


  #####
  ## DT

  br(),
  #DTOutput("id_tablaDT"),

  # br(),
  actionButton("boton", label="Ver base de datos"),


  ############
  ## reactable

  br(),
  # reactable(airquality,
  #           searchable = TRUE,
  #           filterable = TRUE
  # )

  # ordenación
  #reactable(airquality, defaultSorted = c("Wind", "Temp"))  # especificamos las columnas por las que apareceran ordenados inicialmente los datos, pero permite ordenar por cualquier columna.

  # agrupación
  #reactable(airquality, groupBy = "Month")

  # totales
  reactableOutput("id_tabla_react")

  # Estilos (algunos ejemplos)
  # reactable(airquality,
  #           searchable = TRUE
  #           ,filterable = TRUE
  #           # Estilos
  #           ,highlight = TRUE   # Marca la fila al pasar el ratón por encima
  #           ,bordered = TRUE    # Bordes de celdas
  #           ,striped = TRUE     # Filas rayadas alternativamente
  #           ,columns = list(
  #             Ozone = colDef(minWidth = 500)   # Ancho de columna --> 500px
  #           )
  # )

  # Temas
  # Estilos (algunos ejemplos)
  # reactable(airquality,
  #           searchable = TRUE
  #           ,filterable = TRUE
  #           # Estilos
  #           ,highlight = TRUE   # Marca la fila al pasar el ratón por encima
  #           ,bordered = TRUE    # Bordes de celdas
  #           ,striped = TRUE     # Filas rayadas alternativamente
  #           ,columns = list(
  #             Ozone = colDef(minWidth = 500)   # Ancho de columna --> 500px
  #           )
  #           ,theme = reactableTheme(
  #             borderColor = "#B52D12",
  #             stripedColor = "#C96451",
  #             highlightColor = "#B52D12",
  #             cellPadding = "8px 12px",
  #             style = list(fontFamily = "sans-serif")
  #           )
  # )


)

