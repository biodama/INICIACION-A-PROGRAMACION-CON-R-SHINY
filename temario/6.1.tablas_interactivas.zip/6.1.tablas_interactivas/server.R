### Parte servidor
###
### 6.1 Tablas interactivas
###

server <- function(input, output) {

    datos <- airquality  # Copia de la BBDD

    ###### DT
    #########

    ## Con filtrado
    #output$id_tablaDT <- DT::renderDT( datatable(datos, filter = "top") )

    ## Editable
    #output$id_tablaDT <- DT::renderDT( datatable(datos, editable = TRUE) )
    #
    # # Capturar modificaciones de la tabla
    observeEvent(input$id_tablaDT_cell_edit, {
      celda <- input$id_tablaDT_cell_edit
      print(c("Valor modificado:", celda))
      datos[celda$row, celda$col] <<- celda$value
    })
    #
    observeEvent(input$boton,{
      print(datos)
    })

    ## Con Descarga de datos
    output$id_tablaDT <- DT::renderDT(
                                datatable(datos,
                                          extensions = "Buttons",
                                          options = list(
                                                         dom = 'Bfrtip',  # muestra botones
                                                         buttons = c('copy', 'csv', 'excel', 'pdf', 'print')
                                                        )
                                         )
                                )


    ###### reactable
    ################

    # Fila de totales
    output$id_tabla_react <- renderReactable(
      reactable(
      data= airquality,
      defaultPageSize = 5,
      columns = list(
        Solar.R = colDef(footer = "Total"),
        Wind = colDef(footer = function(values) sprintf("%.2f", sum(values)))
        ),
      defaultColDef = colDef(footerStyle = list(fontWeight = "bold"))
      )
     )

}
