library("shiny")

shinyUI(
  (htmlOutput("id_app"))
)

