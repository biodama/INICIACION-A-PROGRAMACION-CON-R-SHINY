# Definición de la pantalla 1 de mi app

ui_pantalla1 <- function() {

  tagList(

  br(),
  fluidRow(
    column(2,""),
    column(8, align="center",
              h1(" Pantalla 1 de mi app")
           ),
    column(2,""),
  ),
  br(),
  fluidRow(
    column(2,""),
    column(8, align="center",
           actionButton("id_boton1", label = "ir a pantalla 2")
    ),
    column(2,""),
  )

  )

}
