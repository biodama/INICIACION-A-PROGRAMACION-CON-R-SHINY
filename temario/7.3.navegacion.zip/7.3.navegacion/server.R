### Parte servidor
shinyServer(
  function(input, output, session) {

    source("pantalla1.R", local=TRUE)
    source("pantalla2.R", local=TRUE)

    output$id_app <- renderUI({
      bootstrapPage(ui_pantalla1())
    })

    observeEvent(input$id_boton1,{
      output$id_app <- renderUI({
        bootstrapPage(ui_pantalla2())
      })
    })

    observeEvent(input$id_boton2,{
      output$id_app <- renderUI({
        bootstrapPage(ui_pantalla1())
      })
    })

  }
)
