# Definición de la pantalla 1 de mi app

ui_pantalla2 <- function() {

  tagList(

  fluidRow(
    br(),
    column(2,""),
    column(8, align="center",
              h1(" Pantalla 2 de mi app")
           ),
    column(2,""),
  ),
  br(),
  fluidRow(
    column(2,""),
    column(8, align="center",
           actionButton("id_boton2", label = "ir a pantalla 1")
    ),
    column(2,""),
  )

  )

}
