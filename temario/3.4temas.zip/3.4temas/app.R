###
### 3.4 Temas
###

library(shiny)

library(shiny)
library(bslib)

ui <- fluidPage(
  # theme = bslib::bs_theme(
  #   version = 5,
  #   bg = "#FFFFFF",
  #   fg = "#333333",
  #   primary = "red",
  #   secondary = "#6C757D",
  #   base_font = font_collection("Arial", "sans-serif"),
  #   heading_font = font_collection("Arial", "sans-serif"),
  #   font_scale = 1.1
  # ),
  theme = shinythemes::shinytheme("cyborg"),

  tags$div(titlePanel("Curso de R Shiny"), align="center"),
  br(),
  actionButton("aceptar", "Aceptar", class = "btn-primary"),
  actionButton("cancelar", "Cancelar", class = "btn-secondary"),
  br(),
  textInput("nombre", "Nombre:")
)

shinyApp(ui, function(input, output, session) {})
