library(shiny)
library(visNetwork)

ui <- fluidPage(
  titlePanel("Ejemplo básico de visNetwork en R Shiny"),
  sidebarLayout(
    sidebarPanel(
      sliderInput("num_nodos", "Número de nodos:", min = 3, max = 15, value = 5),
      actionButton("actualizar", "Generar nueva red")
    ),
    mainPanel(
      visNetworkOutput("network", height = "500px"),
      verbatimTextOutput("nodo_seleccionado")
    )
  )
)

server <- function(input, output, session) {

  # Generar datos reactivos según el slider o el botón
  red_datos <- eventReactive(input$actualizar, {
    n <- input$num_nodos
    nodes <- data.frame(
      id = 1:n,
      label = paste("Nodo", 1:n),
      group = sample(c("A", "B"), n, replace = TRUE),
      value = sample(10:30, n, replace = TRUE)
    )

    edges <- data.frame(
      from = sample(1:n, n + 2, replace = TRUE),
      to = sample(1:n, n + 2, replace = TRUE)
    )
    # Evitar enlaces a sí mismo
    edges <- edges[edges$from != edges$to, ]

    list(nodes = nodes, edges = edges)
  }, ignoreNULL = FALSE)

  output$network <- renderVisNetwork({
    datos <- red_datos()
    visNetwork(datos$nodes, datos$edges, width = "100%") %>%
      visOptions(highlightNearest = TRUE, nodesIdSelection = TRUE) %>%
      visInteraction(navigationButtons = TRUE)
  })

  # Mostrar el nodo seleccionado por el usuario
  output$nodo_seleccionado <- renderPrint({
    cat("Nodo seleccionado actualmente:", input$network_selected)
  })
}

shinyApp(ui = ui, server = server)
