library(shiny)
library(collapsibleTree)


ui <- fluidPage(

   # Application title
   titlePanel("Collapsible Tree - Ejemplo"),

   sidebarLayout(
      sidebarPanel(
         selectInput("raiz", "Nodo Raiz", c("Month","Day")),
         tags$p("El último nodo seleccionado:"),
         verbatimTextOutput("str")
      ),

      mainPanel(
         collapsibleTreeOutput("plot")
      )
   )
)

# Define server logic required to draw a collapsible tree diagram
server <- function(input, output) {

   datos <- reactive(airquality[,-c(1:3)]) # temp , mes, dia

   output$plot <- renderCollapsibleTree({
     if(input$raiz=="Month") {
       hierarchy <- c("Month","Day","Temp")
     } else {
       hierarchy <- c("Day","Month","Temp")
     }
     collapsibleTree(
       datos(), hierarchy, input$raiz,
       inputId = "node", linkLength = 100
     )
   })
   output$str <- renderPrint(str(input$node))
}

# Run the application
shinyApp(ui = ui, server = server)
