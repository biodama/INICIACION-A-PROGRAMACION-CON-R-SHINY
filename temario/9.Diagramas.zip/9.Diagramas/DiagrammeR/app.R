library(shiny)
library(DiagrammeR)

# 1. Interfaz de usuario (UI)
ui <- fluidPage(
  titlePanel("Ejemplo de DiagrammeR en R Shiny"),
  sidebarLayout(
    sidebarPanel(
      sliderInput("num_nodos", "Número de nodos:", min = 3, max = 15, value = 5)
    ),
    mainPanel(
      grVizOutput("mi_diagrama", height = "400px")
    )
  )
)

# 2. Lógica del servidor
server <- function(input, output, session) {
  output$mi_diagrama <- renderGrViz({
    # Generar un grafo dinámico según el slider
    n <- input$num_nodos
    
    # Construcción del código DOT de Graphviz
    dot_code <- paste0(
      "digraph {",
      "  graph [rankdir = LR]",
      "  node [shape = circle, style = filled, color =lightblue]",
      "  edge [color = gray]",
      paste(paste0("1 -> ", 2:n), collapse = "; "),
      "}"
    )
    
    grViz(dot_code)
  })
}

# 3. Ejecutar aplicación
shinyApp(ui = ui, server = server)

